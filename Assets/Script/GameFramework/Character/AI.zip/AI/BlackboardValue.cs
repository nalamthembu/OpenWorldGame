﻿using UnityEngine;
using MyBox;

/// <summary>
/// base class for all blackboard values.
/// </summary>
[System.Serializable]
public class BlackBoardValue
{
    public string name;

    [SerializeField] BlackBoardValueType m_BlackboardType;

    [ConditionalField("m_BlackboardType", false, BlackBoardValueType.Boolean)] public bool booleanValue;
    [ConditionalField("m_BlackboardType", false, BlackBoardValueType.Float)] public float floatValue;
    [ConditionalField("m_BlackboardType", false, BlackBoardValueType.Integer)] public int integerValue;
    [ConditionalField("m_BlackboardType", false, BlackBoardValueType.Transform)] public Transform transformValue;
    [ConditionalField("m_BlackboardType", false, BlackBoardValueType.GameObject)] public GameObject gameObjectValue;

    public object GetValue()
    {
        return m_BlackboardType switch
        {
            BlackBoardValueType.Boolean => booleanValue,
            BlackBoardValueType.Float => floatValue,
            BlackBoardValueType.GameObject => gameObjectValue,
            BlackBoardValueType.Integer => integerValue,
            BlackBoardValueType.Transform => transformValue,
            _ => null,
        };
    }
}

public enum BlackBoardValueType
{
    Boolean,
    Float,
    Integer,
    Transform,
    GameObject,
}