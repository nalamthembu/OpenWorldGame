﻿using UnityEngine;

public class BlackBoardComponent : MonoBehaviour
{
    public BlackBoardValue[] m_BlackBoardVariables;
}