﻿using UnityEngine;

[System.Serializable]
public class BaseAITask
{
    public string name;

    //This will return true if the task is performed successfully.
    protected virtual bool PerformTask() 
    { return false; }
}