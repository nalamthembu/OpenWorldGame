﻿using UnityEngine;

public class AITask_MoveTo : BaseAITask
{
    BlackBoardComponent m_BlackBoardComponent;

    [SerializeField] BlackBoardValue PositionValue;
}